function goBack() {
            window.history.back();
        }//function bo dugmay garanawa
console.log("bro xoti mazbwta")